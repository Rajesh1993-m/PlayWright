class Header
{

 constructor(page)
{
this.page=page;
this.profile=page.locator("div[sectionname='Login']");
 }

 async userprofile()
 {
 await this.profile.click();
 }

}

module.exports={Header};